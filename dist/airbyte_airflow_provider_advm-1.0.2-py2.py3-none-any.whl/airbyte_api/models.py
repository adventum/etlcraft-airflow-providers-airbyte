from enum import Enum
from re import L
from typing import Any, Dict, List, Optional, Union

from airbyte_cdk.models import (AdvancedAuth,
                                )
from pydantic import BaseModel, Extra, Field




class AuthFlowType(Enum):
    oauth2_0 = "oauth2.0"
    oauth1_0 = "oauth1.0"

class DestinationSyncMode(Enum):
    append = "append"
    overwrite = "overwrite"
    append_dedup = "append_dedup"


class SyncMode(Enum):
    full_refresh = "full_refresh"
    incremental = "incremental"


class _AirbyteStream(BaseModel):
    class Config:
        extra = Extra.allow

    name: str = Field(..., description="Stream's name.")
    json_schema: Dict[str, Any] = Field(..., description="Stream schema using Json Schema specs.")
    supported_sync_modes: Optional[List[SyncMode]] = None
    source_defined_cursor: Optional[bool] = Field(
        None,
        description="If the source defines the cursor field, then any other cursor field inputs will be ignored. If it does not, either the user_provided one is used, or the default one is used as a backup.",
    )
    default_cursor_field: Optional[List[str]] = Field(
        None,
        description="Path to the field that will be used to determine if a record is new or modified since the last sync. If not provided by the source, the end user will have to specify the comparable themselves.",
    )
    source_defined_primary_key: Optional[List[List[str]]] = Field(
        None,
        description="If the source defines the primary key, paths to the fields that will be used as a primary key. If not provided by the source, the end user will have to specify the primary key themselves.",
    )
    namespace: Optional[str] = Field(
        None,
        description="Optional Source-defined namespace. Currently only used by JDBC destinations to determine what schema to write to. Airbyte streams from the same sources should have the same namespace.",
    )




class ConfiguredAirbyteStream(BaseModel):
    class Config:
        extra = Extra.allow

    stream: _AirbyteStream
    sync_mode: SyncMode
    cursor_field: Optional[List[str]] = Field(
        None,
        description="Path to the field that will be used to determine if a record is new or modified since the last sync. This field is REQUIRED if `sync_mode` is `incremental`. Otherwise it is ignored.",
    )
    destination_sync_mode: DestinationSyncMode
    primary_key: Optional[List[List[str]]] = Field(
        None,
        description="Paths to the fields that will be used as primary key. This field is REQUIRED if `destination_sync_mode` is `*_dedup`. Otherwise it is ignored.",
    )


class ConfiguredAirbyteCatalog(BaseModel):
    class Config:
        extra = Extra.allow

    streams: List[ConfiguredAirbyteStream]


class AuthType(Enum):
    oauth2_0 = "oauth2.0"


class OAuth2Specification(BaseModel):
    class Config:
        extra = Extra.allow

    rootObject: Optional[list[Union[str, int]]] = Field(
        None,
        description="A list of strings representing a pointer to the root object which contains any oauth parameters in the ConnectorSpecification.\nExamples:\nif oauth parameters were contained inside the top level, rootObject=[] If they were nested inside another object {'credentials': {'app_id' etc...}, rootObject=['credentials'] If they were inside a oneOf {'switch': {oneOf: [{client_id...}, {non_oauth_param]}},  rootObject=['switch', 0] ",
    )
    oauthFlowInitParameters: Optional[List[List[str]]] = Field(
        None,
        description="Pointers to the fields in the rootObject needed to obtain the initial refresh/access tokens for the OAuth flow. Each inner array represents the path in the rootObject of the referenced field. For example. Assume the rootObject contains params 'app_secret', 'app_id' which are needed to get the initial refresh token. If they are not nested in the rootObject, then the array would look like this [['app_secret'], ['app_id']] If they are nested inside an object called 'auth_params' then this array would be [['auth_params', 'app_secret'], ['auth_params', 'app_id']]",
    )
    oauthFlowOutputParameters: Optional[List[List[str]]] = Field(
        None,
        description="Pointers to the fields in the rootObject which can be populated from successfully completing the oauth flow using the init parameters. This is typically a refresh/access token. Each inner array represents the path in the rootObject of the referenced field.",
    )

class OAuthConfigSpecification(BaseModel):
    class Config:
        extra = Extra.allow

    oauth_user_input_from_connector_config_specification: Optional[Dict[str, Any]] = Field(
        None,
        description="OAuth specific blob. This is a Json Schema used to validate Json configurations used as input to OAuth.\nMust be a valid non-nested JSON that refers to properties from ConnectorSpecification.connectionSpecification\nusing special annotation 'path_in_connector_config'.\nThese are input values the user is entering through the UI to authenticate to the connector, that might also shared\nas inputs for syncing data via the connector.\n\nExamples:\n\nif no connector values is shared during oauth flow, oauth_user_input_from_connector_config_specification=[]\nif connector values such as 'app_id' inside the top level are used to generate the API url for the oauth flow,\n  oauth_user_input_from_connector_config_specification={\n    app_id: {\n      type: string\n      path_in_connector_config: ['app_id']\n    }\n  }\nif connector values such as 'info.app_id' nested inside another object are used to generate the API url for the oauth flow,\n  oauth_user_input_from_connector_config_specification={\n    app_id: {\n      type: string\n      path_in_connector_config: ['info', 'app_id']\n    }\n  }",
    )
    complete_oauth_output_specification: Optional[Dict[str, Any]] = Field(
        None,
        description="OAuth specific blob. This is a Json Schema used to validate Json configurations produced by the OAuth flows as they are\nreturned by the distant OAuth APIs.\nMust be a valid JSON describing the fields to merge back to `ConnectorSpecification.connectionSpecification`.\nFor each field, a special annotation `path_in_connector_config` can be specified to determine where to merge it,\n\nExamples:\n\n    complete_oauth_output_specification={\n      refresh_token: {\n        type: string,\n        path_in_connector_config: ['credentials', 'refresh_token']\n      }\n    }",
    )
    complete_oauth_server_input_specification: Optional[Dict[str, Any]] = Field(
        None,
        description="OAuth specific blob. This is a Json Schema used to validate Json configurations persisted as Airbyte Server configurations.\nMust be a valid non-nested JSON describing additional fields configured by the Airbyte Instance or Workspace Admins to be used by the\nserver when completing an OAuth flow (typically exchanging an auth code for refresh token).\n\nExamples:\n\n    complete_oauth_server_input_specification={\n      client_id: {\n        type: string\n      },\n      client_secret: {\n        type: string\n      }\n    }",
    )
    complete_oauth_server_output_specification: Optional[Dict[str, Any]] = Field(
        None,
        description="OAuth specific blob. This is a Json Schema used to validate Json configurations persisted as Airbyte Server configurations that\nalso need to be merged back into the connector configuration at runtime.\nThis is a subset configuration of `complete_oauth_server_input_specification` that filters fields out to retain only the ones that\nare necessary for the connector to function with OAuth. (some fields could be used during oauth flows but not needed afterwards, therefore\nthey would be listed in the `complete_oauth_server_input_specification` but not `complete_oauth_server_output_specification`)\nMust be a valid non-nested JSON describing additional fields configured by the Airbyte Instance or Workspace Admins to be used by the\nconnector when using OAuth flow APIs.\nThese fields are to be merged back to `ConnectorSpecification.connectionSpecification`.\nFor each field, a special annotation `path_in_connector_config` can be specified to determine where to merge it,\n\nExamples:\n\n      complete_oauth_server_output_specification={\n        client_id: {\n          type: string,\n          path_in_connector_config: ['credentials', 'client_id']\n        },\n        client_secret: {\n          type: string,\n          path_in_connector_config: ['credentials', 'client_secret']\n        }\n      }",
    )


class AuthSpecification(BaseModel):
    auth_type: Optional[AuthType] = None
    oauth2Specification: Optional[OAuth2Specification] = Field(
        None,
        description="If the connector supports OAuth, this field should be non-null.",
    )


class AdvancedAuth(BaseModel):
    auth_flow_type: Optional[AuthFlowType] = None
    predicate_key: Optional[List[str]] = Field(
        None,
        description="Json Path to a field in the connectorSpecification that should exist for the advanced auth to be applicable.",
    )
    predicate_value: Optional[str] = Field(
        None,
        description="Value of the predicate_key fields for the advanced auth to be applicable.",
    )
    oauth_config_specification: Optional[OAuthConfigSpecification] = None


class StreamDescriptor(BaseModel):
    class Config:
        extra = Extra.allow

    name: str
    namespace: Optional[str] = None



class AirbyteStateBlob(BaseModel):
    pass

    class Config:
        extra = Extra.allow

class AirbyteStreamState(BaseModel):
    class Config:
        extra = Extra.allow

    stream_descriptor: StreamDescriptor
    stream_state: Optional[AirbyteStateBlob] = None


class AirbyteCatalog(BaseModel):
    class Config:
        extra = Extra.allow

    streams: list[_AirbyteStream]


class AirbyteGlobalState(BaseModel):
    class Config:
        extra = Extra.allow

    shared_state: Optional[AirbyteStateBlob] = None
    stream_states: list[AirbyteStreamState]


class JobStatus(Enum):
    RUNNING = 'running'
    SUCCEEDED = "succeeded"
    CANCELLED = "cancelled"
    PENDING = "pending"
    FAILED = "failed"
    ERROR = "error"
    INCOMPLETE = "incomplete"


def to_camel(string: str) -> str:
    return ''.join(
        word.capitalize() if word_n > 0 else word
        for word_n, word in enumerate(string.split('_')))


class ApiBaseModel(BaseModel):
    class Config:
        alias_generator = to_camel
        allow_population_by_field_name = True
        extra = Extra.allow


class AirbyteStream(ApiBaseModel):

    name: str
    json_schema: Dict[str, Any]
    supported_sync_modes: Optional[list[SyncMode]]
    source_defined_cursor: Optional[bool]
    default_cursor_field: Optional[list[str]]
    source_defined_primary_key: Optional[list[list[str]]]
    namespace: Optional[str]


class GetJobRequest(ApiBaseModel):
    id: int


class Pagination(ApiBaseModel):
    page_size: int
    row_offset: int


class ListJobsRequest(ApiBaseModel):
    config_types: list[str]
    config_id: str
    including_job_id: int
    pagination: Pagination


class ResourceRequirements(ApiBaseModel):
    cpu_request: str
    cpu_limit: str
    memory_request: str
    memory_limit: str

    class Config:
        def alias_generator(field_name): return field_name


class JobSpecificResourceRequirements(ApiBaseModel):
    job_type: str
    resource_requirements: ResourceRequirements


class DefinitionResourceRequirements(ApiBaseModel):
    default: ResourceRequirements
    job_specific: Optional[list[JobSpecificResourceRequirements]]


class CreateSourceDefinitionRequest(ApiBaseModel):
    name: str
    docker_repository: str
    docker_image_tag: str
    documentation_url: str
    icon: Optional[str]
    resource_requirements: Optional[DefinitionResourceRequirements]


class UpdateSourceDefinitionRequest(ApiBaseModel):
    source_definition_id: str
    docker_image_tag: str


class GetSourceDefinitionRequest(ApiBaseModel):
    source_definition_id: str


class DeleteSourceDefinitionRequest(ApiBaseModel):
    source_definition_id: str


class ListPrivateSourceDefinitionRequest(ApiBaseModel):
    workspace_id: str


class ListSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    workspace_id: str


class CreateCustomSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    workspace_id: str
    source_definition: CreateSourceDefinitionRequest


class GetSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    workspace_id: str
    source_definition_id: str


class UpdateCustomSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    workspace_id: str
    source_definition: UpdateSourceDefinitionRequest


class DeleteCustomSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    workspace_id: str
    source_definition_id: UpdateSourceDefinitionRequest


class GrantPrivateSourceDefinitionForWorkspaceRequest(ApiBaseModel):
    source_definition_id: str
    workspace_id: str


class SourceDefinition(ApiBaseModel):
    source_definition_id: str
    name: str
    docker_repository: str
    docker_image_tag: str
    documentation_url: Optional[str]
    icon: Optional[str]
    protocol_version: Optional[str]
    release_stage: Optional[str]
    release_date: Optional[str]
    source_type: Optional[str]
    resource_requirements: Optional[DefinitionResourceRequirements]


class PrivateSourceDefinition(ApiBaseModel):
    source_definition: SourceDefinition
    granted: bool


class Logs(ApiBaseModel):
    log_lines: list[str]


class JobInfo(ApiBaseModel):
    id: str
    config_type: str
    config_if: Optional[str]
    created_at: int
    ended_at: int
    succeeded: Optional[bool]
    logs: Logs


class SourceDefinitionSpecification(ApiBaseModel):
    source_definition_id: str
    documentation_uri: Optional[str]
    connection_specification: Dict[str, Any]
    auth_specification: Optional[AuthSpecification]
    advanced_auth: Optional[AdvancedAuth]
    job_info: JobInfo


class DestinationDefinitionSpecification(ApiBaseModel):
    destination_definition_id: str
    documentation_uri: str
    connection_specification: Dict[str, Any]
    auth_specification: AuthSpecification
    advanced_auth: AdvancedAuth
    job_info: JobInfo


class CreateSourceRequest(ApiBaseModel):
    source_definition_id: str
    connection_configuration: Dict[str, Any]
    workspace_id: str
    name: str


class UpdateSourceRequest(ApiBaseModel):
    source_id: str
    connection_configuration: Optional[Dict[str, Any]]
    name: Optional[str]


class CheckSourceConnectionRequest(ApiBaseModel):
    source_id: str


class CheckConnectionForUpdateRequest(ApiBaseModel):
    source_id: str
    connection_configuration: Dict[str, Any]
    name: str


class ListWorkspaceSourcesRequest(ApiBaseModel):
    workspace_id: str


class GetSourceRequest(ApiBaseModel):
    source_id: str


class GetSourceDefinitionSpecificationRequest(ApiBaseModel):
    source_definition_id: str
    workspace_id: str


class Source(ApiBaseModel):
    source_definition_id: str
    source_id: str
    workspace_id: str
    connection_configuration: Dict[str, Any]
    name: str
    source_name: str


class SourceConfiguration(ApiBaseModel):
    connection_configuration: Dict[str, Any]
    name: str


class DeleteSourceRequest(ApiBaseModel):
    source_id: str


class CloneSourceRequest(ApiBaseModel):
    source_clone_id: str
    source_configuration: SourceConfiguration


class SearchSourceRequest(ApiBaseModel):
    source_definitionId: Optional[str]
    source_id: Optional[str]
    workspace_id: Optional[str]
    connection_configuration: Optional[Dict[str, Any]]
    name: Optional[str]
    source_name: Optional[str]


class CheckConnectionStatus(ApiBaseModel):
    status: str
    message: Optional[str]
    job_info: JobInfo


class CreateDestinationDefinitionRequest(ApiBaseModel):
    name: str
    docker_repository: str
    docker_image_tag: str
    documentation_url: str
    icon: str = None
    resource_requirements: DefinitionResourceRequirements = None


class UpdateDestinationDefinitionRequest(ApiBaseModel):
    destination_definition_id: str
    docker_image_tag: str
    resource_requirements: DefinitionResourceRequirements = None


class DiscoverSourceSchemaRequest(ApiBaseModel):
    source_id: str
    disable_cache: bool


class DeleteConnectionRequest(ApiBaseModel):
    connection_id: str


class SourceDiscoverSchemaJob(ApiBaseModel):
    catalog: AirbyteCatalog
    job_info: JobInfo
    catalog_id: str


class DestinationDefinition(ApiBaseModel):
    destination_definition_id: str
    name: str
    docker_repository: str
    docker_image_tag: str
    documentation_uri: str
    icon: str
    protocol_version: str
    release_stage: str
    release_date: str
    source_type: str
    resource_requirements: DefinitionResourceRequirements


class GetDestinationDefinitionRequest(ApiBaseModel):
    destination_definition_id: str


class DeleteDestinationDefinitionRequest(ApiBaseModel):
    destination_definition_id: str


class ListPrivateDestinationDefinitionRequest(ApiBaseModel):
    workspace_id: str


class Destination(ApiBaseModel):
    destination_definition_id: str
    destination_id: str
    workspase_id: str
    connection_configuration: Dict[str, Any]
    name: str
    destination_name: str


class CreateDestinationRequest(ApiBaseModel):
    workspase_id: str
    name: str
    destination_definition_id: str
    connection_configuration: Dict[str, Any]


class UpdateDestinationRequest(ApiBaseModel):
    destination_id: str
    connection_configuration: Dict[str, Any]
    name: str


class ListDestinationsRequest(ApiBaseModel):
    worlspace_id: str


class GetDestinationRequest(ApiBaseModel):
    destination_id: str


class SearchDestinationsRequest(ApiBaseModel):
    destination_definition_id: str
    destination_id: str
    workspase_id: str
    connection_configuration: Dict[str, Any]
    name: str
    destination_name: str


class CheckDestinationConnectionRequest(ApiBaseModel):
    destination_id: str


class CheckDestinationConnectionForUpdateRequest(ApiBaseModel):
    destination_id: str
    connection_configuration: Dict[str, Any]
    name: str


class DeleteDestinationRequest(ApiBaseModel):
    destination_id: str


class DestinationConfiguration(ApiBaseModel):
    connection_configuration: Dict[str, Any]
    name: str


class CreateConnectionRequest(ApiBaseModel):
    name: str
    namespace_definition: str
    namespace_format: str
    prefix: str
    source_id: str
    destination_id: str
    operations_ids: list[str]
    sync_catalog: ConfiguredAirbyteCatalog


class CloneDestinationRequest(ApiBaseModel):
    destination_clone_id: str
    destination_configuration: DestinationConfiguration


class GetDestinationDefinitionSpecificationRequest(ApiBaseModel):
    destination_definition_id: str
    workspace_id: str


class ConnectionSchedule(ApiBaseModel):
    time_unit: str
    units: int


class ConnectionScheduleCron(ApiBaseModel):
    cron_expression: str
    cron_timezone: str


class ConnectionScheduleData(ApiBaseModel):
    basic_schedule: ConnectionSchedule
    cron: ConnectionScheduleCron


class ConnectionSyncCatalogStreamConfig(ApiBaseModel):
    sync_mode: SyncMode
    cursor_field: list[str]
    destination_sync_mode: DestinationSyncMode
    primary_key: list[list[str]]
    alias_name: str
    selected: bool


class ConnectionSyncCatalogStream(ApiBaseModel):
    stream: AirbyteStream
    config: ConnectionSyncCatalogStreamConfig


class ConnectionSyncCatalog(ApiBaseModel):
    streams: list[ConnectionSyncCatalogStream]


class UpdateConnectionRequest(ApiBaseModel):
    connection_id: str
    namespace_definition: Optional[str]
    namespace_format: Optional[str]
    name: Optional[str]
    prefix: Optional[str]
    operation_ids: Optional[list[str]]
    sync_catalog: Optional[ConnectionSyncCatalog]
    schedule: Optional[ConnectionSchedule]
    schedule_type: Optional[str]
    schedule_data: ConnectionScheduleData
    status: Optional[str]
    resource_requirements: Optional[ResourceRequirements]
    source_catalog_id: Optional[str]


class SlackConfiguration(ApiBaseModel):
    webhook: str


class Notification(ApiBaseModel):
    notificationType: str
    send_on_success: bool
    send_on_failure: bool
    slack_configuration: SlackConfiguration
    customerio_configuration: Dict[str, Any]


class Workspace(ApiBaseModel):
    workspace_id: str
    customer_id: str
    email: str
    name: str
    slug: str
    initial_setup_complete: bool
    display_setup_wizard: bool
    anonimous_data_collection: Optional[bool]
    news: bool
    security_updates: bool
    notifications: list[Notification]
    first_completed_sync: Optional[bool]
    feedback_done: Optional[bool]


class ConnectionsListRequest(ApiBaseModel):
    workspace_id: str


class GetConnectionRequest(ApiBaseModel):
    connection_id: str


class GetConnectionStateRequest(ApiBaseModel):
    connection_id: str


class ListAllConnectionRequest(ApiBaseModel):
    workspace_id: str


class Connection(ApiBaseModel):
    """ Describes Airbyte connection between source and destination"""

    connection_id: str
    name: str
    namespace_definition: str
    namespace_format: str
    prefix: str
    source_id: str
    destination_id: str
    operation_ids: list[str]
    sync_catalog: ConnectionSyncCatalog
    schedule: Optional[ConnectionSchedule]
    schedule_type: Optional[str]
    schedule_data: Optional[ConnectionScheduleData]
    status: str
    resource_requirements: Optional[ResourceRequirements]
    source_catalog_id: str


class SearchConnectionsRequest(ApiBaseModel):
    connection_id: Optional[str]
    name: Optional[str]
    namespace_definition: Optional[str]
    namespace_format: Optional[str]
    prefix: Optional[str]
    source_id: Optional[str]
    destination_id: Optional[str]
    schedule: Optional[ConnectionSchedule]
    schedule_type: Optional[str]
    schedule_data: Optional[ConnectionScheduleData]
    status: Optional[str]
    source: Optional[Source]
    destination: Optional[Destination]


class HealthCheckStatus(ApiBaseModel):
    available: bool


class ConnectionState(ApiBaseModel):
    state_type: str
    connection_id: str
    state: Dict[str, Any]
    stream_state: list[AirbyteStreamState]
    global_state: AirbyteGlobalState


class SyncConnectionRequest(ApiBaseModel):
    connection_id: str


class GetConnectionStateTypeRequest(ApiBaseModel):
    connection_id: str


class ResetConnectionRequest(ApiBaseModel):
    connection_id: str


class CreateOrUpdateConnectionStateRequest(ApiBaseModel):
    connection_id: str
    connection_state: ConnectionState


class JobDefinitionResetConfig(ApiBaseModel):
    streams_to_reset: list[StreamDescriptor]


class JobDefinition(ApiBaseModel):
    id: int
    config_type: str
    config_id: str
    created_at: int
    updated_at: int
    status: JobStatus
    reset_config: Optional[JobDefinitionResetConfig]


class StreamStat(ApiBaseModel):
    records_emitted: int
    bytes_emitted: int
    state_messages_emitted: int
    records_committed: int


class StreamStatsDefinition(ApiBaseModel):
    stream_name: str
    stats: StreamStat


class JobFailure(ApiBaseModel):
    failure_origin: str
    failure_type: str
    external_message: str
    internal_message: str
    stack_trace: str
    retryable: bool
    timestamp: int


class JobFailureSummary(ApiBaseModel):
    failures: list[JobFailure]
    partial_success: bool


class JobAttemptDefinition(ApiBaseModel):
    id: int
    status: str
    created_at: str
    updated_at: str
    ended_at: str
    bytes_synced: str
    records_synced: str
    total_stats: StreamStat
    stream_stats: list[StreamStatsDefinition]
    failure_summary: JobFailureSummary


class JobAttemptLogs(ApiBaseModel):
    log_lines: list[str]


class JobAttempt(ApiBaseModel):
    attempt: JobAttemptDefinition
    logs: JobAttemptLogs


class DetailedJob(ApiBaseModel):
    job: JobDefinition
    attempts: list[JobAttempt]


class Job(ApiBaseModel):
    job: JobDefinition


class CancelJobRequest(ApiBaseModel):
    id: int
